﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Introduccion_Ide_visual_Studio
{
    public partial class FormAnchor : Form
    {
        public FormAnchor()
        {
            InitializeComponent();
        }
    }
}
