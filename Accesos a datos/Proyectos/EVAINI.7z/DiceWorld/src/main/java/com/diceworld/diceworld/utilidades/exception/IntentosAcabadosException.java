package com.diceworld.diceworld.utilidades.exception;

public class IntentosAcabadosException extends RuntimeException{

}
