﻿namespace Introduccion_Ide_visual_Studio
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAceptar = new Button();
            btnCancelar = new Button();
            txbUser = new TextBox();
            label1 = new Label();
            lblUsuario = new Label();
            txbPassword = new TextBox();
            SuspendLayout();
            // 
            // btnAceptar
            // 
            btnAceptar.Anchor = AnchorStyles.Bottom;
            btnAceptar.Location = new Point(146, 392);
            btnAceptar.Name = "btnAceptar";
            btnAceptar.Size = new Size(105, 33);
            btnAceptar.TabIndex = 0;
            btnAceptar.Text = "Aceptar";
            btnAceptar.UseVisualStyleBackColor = true;
            btnAceptar.Click += button1_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.Anchor = AnchorStyles.Bottom;
            btnCancelar.Location = new Point(399, 392);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(105, 33);
            btnCancelar.TabIndex = 1;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // txbUser
            // 
            txbUser.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txbUser.Location = new Point(203, 153);
            txbUser.Name = "txbUser";
            txbUser.Size = new Size(362, 27);
            txbUser.TabIndex = 3;
            txbUser.TextChanged += textBox1_TextChanged;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.Location = new Point(99, 246);
            label1.Name = "label1";
            label1.Size = new Size(86, 20);
            label1.TabIndex = 4;
            label1.Text = "Contraseña:";
            // 
            // lblUsuario
            // 
            lblUsuario.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            lblUsuario.AutoSize = true;
            lblUsuario.Location = new Point(99, 153);
            lblUsuario.Name = "lblUsuario";
            lblUsuario.Size = new Size(62, 20);
            lblUsuario.TabIndex = 2;
            lblUsuario.Text = "Usuario:";
            // 
            // txbPassword
            // 
            txbPassword.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            txbPassword.Location = new Point(203, 243);
            txbPassword.Name = "txbPassword";
            txbPassword.Size = new Size(362, 27);
            txbPassword.TabIndex = 5;
            txbPassword.TextChanged += txbPassword_TextChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(674, 495);
            Controls.Add(btnCancelar);
            Controls.Add(btnAceptar);
            Controls.Add(txbPassword);
            Controls.Add(lblUsuario);
            Controls.Add(label1);
            Controls.Add(txbUser);
            MinimumSize = new Size(500, 500);
            Name = "Form1";
            Text = "Login";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnAceptar;
        private Button btnCancelar;
        private TextBox txbUser;
        private Label label1;
        private Label lblUsuario;
        private TextBox txbPassword;
    }
}
